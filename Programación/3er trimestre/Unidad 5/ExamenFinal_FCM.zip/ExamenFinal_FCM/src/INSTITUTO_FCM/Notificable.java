package INSTITUTO_FCM;

public interface Notificable {
    void recibirCalificacion(Profesor p, Alumno a, Nota nota);
}
